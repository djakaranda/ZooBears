"""Regression checks for the supplied scorer and for this package's stricter checks."""
from copy import deepcopy
from datetime import date
from pathlib import Path
import sys

from check_predictions import compare, load_scorer, read_records

HERE = Path(__file__).resolve().parent


def run(scorer):
    tiers = {name: read_records(HERE / f"{name}.gold.jsonl")
             for name in ("easy", "tricky", "stress")}
    for name, gold in tiers.items():
        r = compare(gold, gold, scorer)
        assert r["strict"]["passed"] == len(gold), (name, r["strict"])
        for metric in ("fact_precision", "fact_recall", "temporal_recall",
                       "state_accuracy", "grounding_turn", "grounding_span"):
            assert r["official"][metric] == 1.0, (name, metric, r["official"])
        excluded = {x["call_id"] for x in r["official_excluded_calls"]}
        expected_excluded = ({"zb-v21-stress-06:call0000", "zb-v21-stress-17:call0000"}
                             if name == "stress" else set())
        assert excluded == expected_excluded, (name, excluded)
    print("Gold strict self-check passed in all tiers. Two scorer crashes were isolated.")

    expected = tiers["tricky"]["zb-v21-tricky-12:call0000"]
    pred = deepcopy(expected)
    pred["facts"][0]["valid_to"] = "2026-11-19T17:00:00"
    report = compare({expected["call_id"]: expected}, {pred["call_id"]: pred}, scorer)
    assert report["official"]["temporal_recall"] == 1.0
    assert report["strict"]["passed"] == 0
    print("Wrong hour slips through official day matching, but fails exact interval check")

    expected = tiers["stress"]["zb-v21-stress-10:call0000"]
    pred = deepcopy(expected)
    pred["facts"][0]["valid_from"] = "2026-11-18T10:30:00"
    r = compare({expected["call_id"]: expected}, {pred["call_id"]: pred}, scorer)
    assert r["official"]["n_temporal"] == 0
    assert r["strict"]["passed"] == 1
    print("Action and unstated ticket dates are absent from temporal scoring")

    expected = tiers["tricky"]["zb-v21-tricky-11:call0000"]
    pred = deepcopy(expected)
    pred["facts"][0]["object"], pred["facts"][1]["object"] = (
        pred["facts"][1]["object"], pred["facts"][0]["object"])
    r = compare({expected["call_id"]: expected}, {pred["call_id"]: pred}, scorer)
    assert r["official"]["state_accuracy"] == 0.0
    assert r["official"]["fact_recall"] == 0.0
    print("Swapping the devices breaks matching and state accuracy")

    expected = tiers["tricky"]["zb-v21-tricky-09:call0000"]
    pred = deepcopy(expected)
    pred["facts"][0]["polarity"] = 1
    assert compare({expected["call_id"]: expected}, {pred["call_id"]: pred}, scorer
                   )["official"]["fact_recall"] == 0.0
    print("Flipping polarity breaks fact matching")

    gold = tiers["tricky"]
    refused = gold["zb-v21-tricky-03:call0000"]
    asserted = deepcopy(gold["zb-v21-tricky-02:call0000"]["facts"][0])
    asserted["source"] = {"turn_idx": 1}
    pred = dict(refused, facts=[asserted])
    r = compare({refused["call_id"]: refused}, {pred["call_id"]: pred}, scorer)
    assert r["strict"]["cases"][0]["errors"] == ["extra_or_invalid_facts:1"]
    print("A valid empty result passes, but one false agreement fails")

    for phrase, wanted in [
        ("в прошлом месяце", date(2026, 10, 5)),
        ("на следующей неделе", date(2026, 11, 23)),
        ("дней 3 назад", date(2026, 11, 15)),
    ]:
        assert wanted in scorer.recover_dates(phrase, date(2026, 11, 18)), phrase
    print("v2.1 calendar anchors checked")
    for phrase in ("через две недели", "на позапрошлой неделе"):
        try:
            scorer.recover_dates(phrase, date(2026, 11, 18))
        except TypeError as exc:
            assert "not iterable" in str(exc), (phrase, exc)
        else:
            raise AssertionError(f"Expected known v2.1 scorer failure: {phrase}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python3 test_scorer.py PATH/case_metrics.py PATH/catalog.json")
    run(load_scorer(Path(sys.argv[1]), Path(sys.argv[2])))
