"""Compare one ZooBears test tier with the official v2.1 scorer and stricter checks."""
import argparse
from datetime import datetime, time
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


def read_records(path):
    records = {}
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            record = json.loads(line)
            call_id = record["call_id"]
            if call_id in records:
                raise ValueError(f"{path}:{line_number}: duplicate call_id {call_id}")
            if not isinstance(record.get("facts"), list) or any(
                not isinstance(fact, dict) for fact in record["facts"]
            ):
                raise ValueError(f"{path}:{line_number}: facts must be an array of objects")
            records[call_id] = record
    return records


def load_scorer(path, catalog):
    spec = spec_from_file_location("official_metrics_v21", path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load scorer {path}")
    scorer = module_from_spec(spec)
    spec.loader.exec_module(scorer)
    if str(scorer.VERSION) != "2.1":
        raise ValueError(f"Expected official scorer 2.1, got {scorer.VERSION}")
    if not catalog.is_file() or catalog.name != "catalog.json":
        raise ValueError("Point --catalog to catalog.json from the v2.1 package")
    scorer.load_catalog(str(catalog))
    return scorer


def check_fact_schema(fact, turns):
    errors = []
    object_value = fact.get("object")
    if not isinstance(object_value, dict) or not isinstance(object_value.get("name"), str):
        errors.append("object.name")
    if fact.get("attribute") not in (
        "service_state", "tariff", "ticket_status", "action", "agreement",
    ):
        errors.append("attribute")
    if not isinstance(fact.get("value"), str) or not fact["value"].strip():
        errors.append("value")
    if type(fact.get("polarity")) is not int or fact["polarity"] not in (-1, 1):
        errors.append("polarity")
    try:
        begin = datetime.fromisoformat(fact["valid_from"])
        end = None if fact["valid_to"] is None else datetime.fromisoformat(fact["valid_to"])
        if end is not None and end < begin:
            errors.append("inverted_interval")
    except (KeyError, TypeError, ValueError):
        errors.append("invalid_time")
    src = fact.get("source")
    if not isinstance(src, dict) or type(src.get("turn_idx")) is not int or src["turn_idx"] not in turns:
        return errors + ["source.turn_idx"]
    turn = turns[src["turn_idx"]]
    if "speaker" in fact and fact["speaker"] != turn["speaker"]:
        errors.append("speaker")
    span = src.get("span")
    quote = src.get("quote")
    if span is not None:
        if (not isinstance(span, list) or len(span) != 2
                or any(type(offset) is not int for offset in span)
                or not (0 <= span[0] < span[1] <= len(turn["text"]))):
            errors.append("source.span")
        elif quote is not None and turn["text"][span[0]:span[1]] != quote:
            errors.append("source.quote")
    elif quote is not None and (not isinstance(quote, str) or quote not in turn["text"]):
        errors.append("source.quote")
    return errors


def correct_time(expected, prediction, anchor):
    if expected is None or prediction is None:
        return expected is prediction
    expected = datetime.fromisoformat(expected)
    prediction = datetime.fromisoformat(prediction)
    if expected == datetime.fromisoformat(anchor) or expected.time() == time.min:
        return expected.date() == prediction.date()
    return expected == prediction


def compare(gold, predictions, scorer):
    cases = []
    sanitized = {}
    scorable = {}
    official_errors = []
    for call_id, target in gold.items():
        # Probe recovery even if the model missed the fact. Otherwise the
        # scorer crash depends on whether the prediction happened to match.
        try:
            call_day = datetime.fromisoformat(target["started_at"]).date()
            for turn in target["turns"]:
                scorer.recover_dates(turn["text"], call_day)
        except TypeError as exc:
            official_errors.append({"call_id": call_id, "error": f"TypeError: {exc}"})
        else:
            scorable[call_id] = target
        if call_id not in predictions:
            cases.append({"call_id": call_id, "errors": ["missing_call"]})
            continue
        turns = {turn["idx"]: turn for turn in target["turns"]}
        facts = predictions[call_id]["facts"]
        errors, valid = [], []
        for index, fact in enumerate(facts):
            issues = check_fact_schema(fact, turns)
            errors.extend(f"fact[{index}].{issue}" for issue in issues)
            if not issues:
                valid.append(fact)
        sanitized[call_id] = {"facts": valid}
        expected = target["facts"]
        matched = scorer.match_facts(expected, valid)
        if len(matched) < len(expected):
            errors.append(f"missing_facts:{len(expected) - len(matched)}")
        if len(matched) < len(facts):
            errors.append(f"extra_or_invalid_facts:{len(facts) - len(matched)}")
        for ref, pred, _ in matched:
            label = ref["attribute"] + "/" + ref["object"]["name"]
            source = ref["source"]
            predicted_source = pred["source"]
            if source["turn_idx"] != predicted_source["turn_idx"]:
                errors.append(f"{label}.wrong_source")
            elif source.get("span") and predicted_source.get("span"):
                a, b = source["span"]
                c, d = predicted_source["span"]
                if max(a, c) >= min(b, d):
                    errors.append(f"{label}.wrong_span")
            if ref["attribute"] != "action":
                for key in ("valid_from", "valid_to"):
                    if not correct_time(ref.get(key), pred.get(key), target["started_at"]):
                        errors.append(f"{label}.{key}")
        cases.append({"call_id": call_id, "errors": errors})
    for call_id in sorted(predictions.keys() - gold.keys()):
        cases.append({"call_id": call_id, "errors": ["unknown_call"]})
    return {
        "official": scorer.evaluate(scorable, sanitized) if scorable else None,
        "official_excluded_calls": official_errors,
        "strict": {"passed": sum(not case["errors"] for case in cases),
                   "total": len(cases), "cases": cases},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("gold", type=Path)
    parser.add_argument("predictions", type=Path)
    parser.add_argument("--scorer", type=Path, required=True)
    parser.add_argument("--catalog", type=Path, required=True)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    scorer = load_scorer(args.scorer, args.catalog)
    report = compare(read_records(args.gold), read_records(args.predictions), scorer)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.out:
        args.out.write_text(rendered, encoding="utf-8")
        print(json.dumps({"official": report["official"],
                          "official_excluded": len(report["official_excluded_calls"]),
                          "strict_passed": report["strict"]["passed"],
                          "strict_total": report["strict"]["total"]}, ensure_ascii=False))
    else:
        print(rendered, end="")
    return int(report["strict"]["passed"] != report["strict"]["total"])


if __name__ == "__main__":
    raise SystemExit(main())
